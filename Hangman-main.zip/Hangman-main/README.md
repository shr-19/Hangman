# Hangman
In this project, we have created a Hangman game with the help of the “Pygame” module in Python language.
Basically, it is a guessing game. The player tries to guess it by suggesting letters within a certain number of guesses. If the guessed word is correct within the given limit then the player got wins. 
If the player selects the wrong letter then every time the wrong selection one of the body parts of the hangman will appear and 
thus when the guessed limit is over the player will lose the game.
